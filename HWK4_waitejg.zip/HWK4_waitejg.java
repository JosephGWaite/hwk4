/*
Name:  Joseph Waite, Joel Straatman, Cassandra Nicolak
MacID: waitejg, straatjc, nicolace
Student Number:  001403712, 001314676, 0971847
Description: Homework 4 Java final
*/
import java.io.Console;

public class HWK4_waitejg{
	public static void main(String[] args){ 

		UserInterface ourUI = new UserInterface(); 
		ourUI.start(); //Calls page 1, and does everything in there. 
							   //If we need to persist user information, then I guess we do that here. 
	}
}